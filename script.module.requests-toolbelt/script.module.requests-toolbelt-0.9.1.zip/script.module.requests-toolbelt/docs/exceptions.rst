.. _exceptions:

Custom Toolbelt Exceptions
==========================

Below are the exception classes used by the toolbelt to provide error details
to the user of the toolbelt.

.. automodule:: requests_toolbelt.exceptions
    :members:
